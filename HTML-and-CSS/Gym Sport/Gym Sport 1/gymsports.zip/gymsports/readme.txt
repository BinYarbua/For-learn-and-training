GYMSports is a simple, clean and modern PSD template for fitness and gym website. It can also be used for any other type of website, especially for sports, spa, events etc.
The template consists of well-organized components that are easy modify.



PSD Template Features:

9 Full layered Adobe Photoshop .PSD files.

1 Home Page

1 About Page

1 Timetible Page

1 Classes Page

1 Class Single Page

1 Blog Page

1 Blog Single Page

1 Pricing Page

1 Contact Page

Clean Flat UI Design

Bootstrap layout ready

Flexible and Multipurpose

Well organized layers makes it very easy ti update.

All Google Web Fonts

.


.GYMSports - Created by Michele Cialone - 2014/theuncreativelab.com

.GYMSports .psd template is licensed under a Creative Commons Attribution 3.0 Unported (CC BY 3.0)  (http://creativecommons.org/licenses/by/3.0/). 

You are allowed to use these elements anywhere you want, however well highly appreciate if you will link to our website when you share them - http://theuncreativelab.com

Thanks for supporting our website and enjoy!

Links:
http://theuncreativelab.com
http://2ndself.com



.GYMSports .psd theme is made using the Open Sans typeface, which can be downloaded for free here: http://www.google.com/fonts/specimen/Open+Sans

Image 